package com.awraad.nooriya;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
