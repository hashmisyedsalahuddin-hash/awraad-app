const CACHE_PREFIX = "awraad-offline-";
const CACHE_NAME = CACHE_PREFIX + "v5";
const PRECACHE_CONCURRENCY = 6;
const ASSETS = [
  "./",
  "./Asma_Un_Nabi.html",
  "./Asma_ul_Husna.html",
  "./Bashair_ul_Khairaat.html",
  "./Daily.html",
  "./Dua_Bada_Dalail-ul-Khairaat.html",
  "./Dua_Iftitah.html",
  "./Dua_Yuqrau_Aqeeb_Alaviyya.html",
  "./Friday_Hizb_Locked.html",
  "./Index.html",
  "./Malfoozaat_e_Bahrul_Irfan.html",
  "./Monday_Hizb1.html",
  "./Monday_Hizb8.html",
  "./Saturday_Hizb_Locked.html",
  "./Shajara_e_Alaviyya.html",
  "./Sunday_Hizb_Locked.html",
  "./Tajweed_Explanation.html",
  "./Tajweed_Style.css",
  "./Tajweed_rules.js",
  "./Tareeqa_Faatiha.html",
  "./Thursday_Hizb_Locked.html",
  "./Tuesday_Hizb_Locked.html",
  "./Usboo_e_Shareef.html",
  "./Wednesday_Hizb_Locked.html",
  "./apple-touch-icon.png",
  "./icon-192.png",
  "./icon-512.png",
  "./icon.jpg",
  "./icon.png",
  "./index.html",
  "./manifest.json",
  "./splash-full.png"
];

self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    const queue = ASSETS.slice();
    const failed = [];

    async function worker() {
      while (queue.length > 0) {
        const relUrl = queue.shift();
        if (!relUrl) break;
        const resolvedUrl = new URL(relUrl, self.registration.scope).href;
        try {
          const response = await fetch(resolvedUrl, { cache: "no-cache" });
          if (!response.ok) {
            failed.push({ url: relUrl, status: response.status });
          } else {
            await cache.put(resolvedUrl, response);
          }
        } catch (err) {
          failed.push({ url: relUrl, error: String(err) });
        }
      }
    }

    const workers = [];
    for (let i = 0; i < Math.min(PRECACHE_CONCURRENCY, ASSETS.length); i++) {
      workers.push(worker());
    }
    await Promise.all(workers);

    if (failed.length > 0) {
      console.error("[Awraad SW] Precache failed for assets:", JSON.stringify(failed));
      throw new Error("Precache failed for " + failed.length + " asset(s)");
    }
    await self.skipWaiting();
  })());
});

self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(
      keys
        .filter(k => k.startsWith(CACHE_PREFIX) && k !== CACHE_NAME)
        .map(k => caches.delete(k))
    );
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  const reqUrl = new URL(event.request.url);
  if (reqUrl.origin !== self.location.origin) return;

  // 2B & 2D: Manage cache write inside respondWith promise lifecycle & use scope-resolved index.html fallback
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cachedResponse = await cache.match(event.request, { ignoreSearch: true });
    if (cachedResponse) return cachedResponse;

    try {
      const networkResponse = await fetch(event.request);
      if (networkResponse && networkResponse.status === 200 && networkResponse.type === "basic") {
        const copy = networkResponse.clone();
        await cache.put(event.request, copy);
      }
      return networkResponse;
    } catch (err) {
      if (event.request.mode === "navigate") {
        const indexScopeUrl = new URL("./index.html", self.registration.scope).href;
        const fallback =
          (await cache.match(indexScopeUrl, { ignoreSearch: true })) ||
          (await cache.match(new URL("./", self.registration.scope).href, { ignoreSearch: true }));
        if (fallback) return fallback;
      }
      return Response.error();
    }
  })());
});
