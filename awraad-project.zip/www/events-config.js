// =========================================================================
// AWRAAD E ALAVIYA NOORIYA — LIVE SESSION (GOOGLE MEET), EVENTS & URS CONFIG
// =========================================================================
// Is file ko jab chahein edit karke naya Google Meet link, Calendar link,
// regular events, ya extra Hijri / Mashaykheen Urs dates add kar sakte hain.
// Shajara_e_Alaviyya.html ke tables se Mashaykheen ke Urs dates khud-ba-khud
// (automatically) Calendar aur Events list mein load ho jate hain!
// =========================================================================

window.AWRAAD_EVENTS_CONFIG = {
    // Shajara_e_Alaviyya.html ke sabhi .shijra-table rows se Mashaykheen ke Urs dates
    // automatically extract karke Calendar & Upcoming Events mein dikhane ke liye true rakhein:
    autoLoadShajaraUrs: true,

    // 1. LIVE SESSION (GOOGLE MEET) SETTINGS
    liveSession: {
        title: "Weekly Online Educational Session",
        titleUr: "ہفتہ وار آن لائن مجلسِ تعلیم و ذکر",
        host: "Silsila e Alaviya Nooriya",
        description: "Har Hafte hone wali online taleemi wa zikr nishist mein shareek hon.",
        // Yahan apna asli Google Meet link paste karein (masalan: "https://meet.google.com/abc-defg-hij")
        meetUrl: "https://meet.google.com/rbg-vcxo-yye",

        // Recurring weekly schedule:
        // dayOfWeek: 0 = Sunday, 1 = Monday, 2 = Tuesday, 3 = Wednesday, 4 = Thursday, 5 = Friday, 6 = Saturday
        isRecurringWeekly: true,
        dayOfWeek: 2,         // Tuesday (Mangal)
        startHour: 8,         // 24-hour format (8 = 8:00 AM, 20 = 8:00 PM)
        startMinute: 0,       // Minutes (0 to 59)
        durationMinutes: 60,  // Session ki muddat minutes mein
        timezoneLabel: "IST",

        // Agar kabhi one-time special session rakhna ho to isRecurringWeekly: false karke
        // customStartISO set karein, masalan: "2026-12-01T20:00:00+05:30"
        customStartISO: ""
    },

    // 2. PUBLIC GOOGLE CALENDAR EMBED URL (Optional)
    // Google Calendar > Settings > Integrate calendar > Embed code se sirf src="..." wala URL paste karein.
    // Khali ("") rakhne par app ka built-in Dual Hijri + Gregorian Calendar show hoga.
    googleCalendarEmbedUrl: "",

    // 3. REGULAR / GREGORIAN EVENTS LIST
    events: [
        {
            id: "weekly-tuesday-session",
            title: "Weekly Online Session (Google Meet)",
            titleUr: "ہفتہ وار آن لائن مجلسِ تعلیم",
            isRecurringWeekly: true,
            dayOfWeek: 2,       // Every Tuesday
            startHour: 8,
            startMinute: 0,
            durationMinutes: 60,
            location: "Google Meet (Online)",
            description: "Har Mangal subah 8:00 baje online taleemi nishist.",
            meetUrl: ""         // Khali rakhein to upar wala liveSession.meetUrl automatically use hoga
        },
        {
            id: "thursday-khatm",
            title: "Shab-e-Jumu'ah Awraad & Durood Gathering",
            titleUr: "شبِ جمعہ محفلِ درود و اوراد",
            isRecurringWeekly: true,
            dayOfWeek: 4,       // Every Thursday
            startHour: 21,      // 9:00 PM
            startMinute: 0,
            durationMinutes: 45,
            location: "Online / Home",
            description: "Shab-e-Jumu'ah mein Dalail-ul-Khairat aur khas Durood Shareef ka ihtimam.",
            meetUrl: ""
        }
    ],

    // 4. EXTRA / CUSTOM HIJRI & URS EVENTS (Optional)
    // Shajara_e_Alaviyya.html ke tamaam Urs dates khud-ba-khud load ho jate hain.
    // Agar koi khaas Urs ya Islamic raat alag se add karni ho to niche format mein add kar sakte hain:
    // hijriMonth: 1=Muharram, 2=Safar, 3=Rabi-ul-Awwal, 4=Rabi-us-Sani, 5=Jumada-ul-Awwal,
    //             6=Jumada-us-Sani, 7=Rajab, 8=Shaban, 9=Ramadan, 10=Shawwal, 11=Zil-Qadah, 12=Zil-Hijjah
    hijriEvents: [
        {
            id: "urs-ghaus-e-azam",
            type: "urs",
            title: "Urs-e-Ghaus-e-Azam (R.A.) — Gyarhween Shareef",
            titleUr: "عرسِ غوثِ اعظم حضرت شیخ عبدالقادر جیلانی رضی اللہ عنہ",
            hijriDay: 11,
            hijriMonth: 4,      // 11 Rabi-us-Sani
            silsila: "Silsila e Qadriya",
            wisaalYear: "561ھ",
            location: "Baghdad Shareef",
            description: "Gyarhween Shareef — Fatiha, Khatm-e-Qadriya aur Isaal-e-Sawab.",
            shajaraHash: "#qadriya"
        },
        {
            id: "urs-khwaja-gharib-nawaz",
            type: "urs",
            title: "Urs-e-Khwaja Gharib Nawaz (R.A.) — Chhati Shareef",
            titleUr: "عرسِ حضرت خواجہ معین الدین چشتی اجمیری رحمۃ اللہ علیہ",
            hijriDay: 6,
            hijriMonth: 7,      // 6 Rajab
            silsila: "Silsila e Chishtiya",
            wisaalYear: "633ھ",
            location: "Ajmer Shareef",
            description: "Chhati Shareef — Khatm-e-Khwajgan aur Fatiha Khwani.",
            shajaraHash: "#chishtiyya"
        }
    ]
};
