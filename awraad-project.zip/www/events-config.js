// =========================================================================
// AWRAAD E ALAVIYA NOORIYA — LIVE SESSION (GOOGLE MEET), EVENTS & URS CONFIG
// =========================================================================
// Is file ko jab chahein edit karke naya Google Meet link, Calendar link,
// regular events, ya extra Hijri / Mashaykheen Urs dates add kar sakte hain.
// Shajara_e_Alaviyya.html ke tables se Mashaykheen ke Urs dates khud-ba-khud
// (automatically) Calendar aur Events list mein load ho jate hain!
// =========================================================================

window.AWRAAD_EVENTS_CONFIG = {
    // Shajara_e_Alaviyya.html ke sabhi .shijra-table rows se Mashaykheen ke Urs dates
    // automatically extract karke Calendar & Upcoming Events mein dikhane ke liye true rakhein:
    autoLoadShajaraUrs: true,

    // 1. LIVE SESSION (PRIMARY)
    liveSession: {
        id: "weekly-tuesday-session",
        title: "Weekly Online Session - Tafseer Ul Quran [ONLY For Ladies]",
        titleUr: "",
        host: "Conducted by: Hazrath Qibla",
        sessionMode: "Session Mode: Online [Google Meet]",
        description: "",
        meetUrl: "",

        // dayOfWeek: 0 = Sunday, 1 = Monday, 2 = Tuesday, 3 = Wednesday, 4 = Thursday, 5 = Friday, 6 = Saturday
        isRecurringWeekly: true,
        dayOfWeek: 2,         // Every Tuesday
        startHour: 11,        // 11:00 AM
        startMinute: 0,
        durationMinutes: 60,  // 11:00 AM to 12:00 PM IST (60 mins)
        showEndTime: true,
        timezoneLabel: "IST",
        location: "Online [Google Meet]",
        customStartISO: ""
    },

    // 1B. LIVE EVENTS LIST (Live Session tab mein dono recurring events show honge)
    liveSessions: [
        {
            id: "weekly-tuesday-session",
            title: "Weekly Online Session - Tafseer Ul Quran [ONLY For Ladies]",
            titleUr: "",
            host: "Conducted by: Hazrath Qibla",
            sessionMode: "Session Mode: Online [Google Meet]",
            description: "",
            meetUrl: "",
            isRecurringWeekly: true,
            dayOfWeek: 2,         // Every Tuesday
            startHour: 11,        // 11:00 AM
            startMinute: 0,
            durationMinutes: 60,  // 11:00 AM to 12:00 PM IST (60 mins)
            showEndTime: true,
            timezoneLabel: "IST",
            location: "Online [Google Meet]",
            customStartISO: ""
        },
        {
            id: "weekly-sunday-halqa",
            title: "Halqa e Zikr o Taalemaat",
            titleUr: "حلقۂ ذکر و تعلیمات",
            host: "",
            sessionMode: "",
            description: "",
            meetUrl: "",
            isRecurringWeekly: true,
            dayOfWeek: 0,         // Every Sunday
            startHour: 16,        // 4:40 PM
            startMinute: 40,
            durationMinutes: 60,
            showEndTime: false,
            timezoneLabel: "IST",
            location: "Khankhaa e Alaviya Nooriya, Saadaat Nagar",
            customStartISO: ""
        }
    ],

    // 2. PUBLIC GOOGLE CALENDAR EMBED URL (Optional)
    googleCalendarEmbedUrl: "",

    // 3. REGULAR / GREGORIAN EVENTS LIST (Calendar & Upcoming tab)
    events: [
        {
            id: "weekly-tuesday-session",
            title: "Weekly Online Session - Tafseer Ul Quran [ONLY For Ladies]",
            titleUr: "",
            isRecurringWeekly: true,
            dayOfWeek: 2,         // Every Tuesday
            startHour: 11,
            startMinute: 0,
            durationMinutes: 60,
            location: "Online [Google Meet]",
            description: "Conducted by: Hazrath Qibla • Session Mode: Online [Google Meet] • 11:00 AM to 12:00 PM IST (60 mins)",
            meetUrl: ""
        },
        {
            id: "weekly-sunday-halqa",
            title: "Halqa e Zikr o Taalemaat",
            titleUr: "حلقۂ ذکر و تعلیمات",
            isRecurringWeekly: true,
            dayOfWeek: 0,         // Every Sunday
            startHour: 16,        // 4:40 PM
            startMinute: 40,
            durationMinutes: 60,
            location: "Khankhaa e Alaviya Nooriya, Saadaat Nagar",
            description: "Every Sunday @ 4:40 PM — Halqa e Zikr o Taalemaat at Khankhaa e Alaviya Nooriya, Saadaat Nagar.",
            meetUrl: ""
        },
        {
            id: "thursday-khatm",
            title: "Shab-e-Jumu'ah Awraad & Durood Gathering",
            titleUr: "شبِ جمعہ محفلِ درود و اوراد",
            isRecurringWeekly: true,
            dayOfWeek: 4,         // Every Thursday
            startHour: 21,        // 9:00 PM
            startMinute: 0,
            durationMinutes: 45,
            location: "Online / Home",
            description: "Shab-e-Jumu'ah mein Dalail-ul-Khairat aur khas Durood Shareef ka ihtimam.",
            meetUrl: ""
        }
    ],

    // 4. EXTRA / CUSTOM HIJRI & URS EVENTS (Optional)
    hijriEvents: [
        {
            id: "urs-ghaus-e-azam",
            type: "urs",
            title: "Urs-e-Ghaus-e-Azam (R.A.) — Gyarhween Shareef",
            titleUr: "عرسِ غوثِ اعظم حضرت شیخ عبدالقادر جیلانی رضی اللہ عنہ",
            hijriDay: 11,
            hijriMonth: 4,      // 11 Rabi-us-Sani
            silsila: "Silsila e Qadriya",
            wisaalYear: "561ھ",
            location: "Baghdad Shareef",
            description: "Gyarhween Shareef — Fatiha, Khatm-e-Qadriya aur Isaal-e-Sawab.",
            shajaraHash: "#qadriya"
        },
        {
            id: "urs-khwaja-gharib-nawaz",
            type: "urs",
            title: "Urs-e-Khwaja Gharib Nawaz (R.A.) — Chhati Shareef",
            titleUr: "عرسِ حضرت خواجہ معین الدین چشتی اجمیری رحمۃ اللہ علیہ",
            hijriDay: 6,
            hijriMonth: 7,      // 6 Rajab
            silsila: "Silsila e Chishtiya",
            wisaalYear: "633ھ",
            location: "Ajmer Shareef",
            description: "Chhati Shareef — Khatm-e-Khwajgan aur Fatiha Khwani.",
            shajaraHash: "#chishtiyya"
        }
    ]
};
