// =========================================================================
// AWRAAD E ALAVIYA NOORIYA — LIVE SESSION (GOOGLE MEET) & EVENTS CONFIG
// =========================================================================
// Is file ko jab chahein edit karke naya Google Meet link, Calendar link,
// ya naye events add/update kar sakte hain (Tajweed_rules.js ko chhedne
// ki zaroorat nahi padegi).
// =========================================================================

window.AWRAAD_EVENTS_CONFIG = {
    // 1. LIVE SESSION (GOOGLE MEET) SETTINGS
    liveSession: {
        title: "Weekly Online Educational Session",
        titleUr: "ہفتہ وار آن لائن مجلسِ تعلیم و ذکر",
        host: "Silsila e Alaviya Nooriya",
        description: "Har Hafte hone wali online taleemi wa zikr nishist mein shareek hon.",
        // Yahan apna asli Google Meet link paste karein (masalan: "https://meet.google.com/abc-defg-hij")
        meetUrl: "https://meet.google.com/your-meeting-code",

        // Recurring weekly schedule:
        // dayOfWeek: 0 = Sunday, 1 = Monday, 2 = Tuesday, 3 = Wednesday, 4 = Thursday, 5 = Friday, 6 = Saturday
        isRecurringWeekly: true,
        dayOfWeek: 2,         // Tuesday (Mangal)
        startHour: 8,         // 24-hour format (8 = 8:00 AM, 20 = 8:00 PM)
        startMinute: 0,       // Minutes (0 to 59)
        durationMinutes: 60,  // Session ki muddat minutes mein
        timezoneLabel: "IST",

        // Agar kabhi one-time special session rakhna ho to isRecurringWeekly: false karke
        // customStartISO set karein, masalan: "2026-12-01T20:00:00+05:30"
        customStartISO: ""
    },

    // 2. PUBLIC GOOGLE CALENDAR EMBED URL (Optional)
    // Google Calendar > Settings > Integrate calendar > Embed code se sirf src="..." wala URL yahan paste karein.
    // Agar khali ("") rakhein to app ka built-in offline Monthly Calendar automatically dikhega.
    googleCalendarEmbedUrl: "",

    // 3. UPCOMING EVENTS LIST (Har event par "Add to Google Calendar" button khud banega)
    events: [
        {
            id: "weekly-tuesday-session",
            title: "Weekly Online Session (Google Meet)",
            titleUr: "ہفتہ وار آن لائن مجلسِ تعلیم",
            isRecurringWeekly: true,
            dayOfWeek: 2,       // Every Tuesday
            startHour: 8,
            startMinute: 0,
            durationMinutes: 60,
            location: "Google Meet (Online)",
            description: "Har Mangal subah 8:00 baje online taleemi nishist.",
            meetUrl: ""         // Khali rakhein to upar wala liveSession.meetUrl automatically use hoga
        },
        {
            id: "thursday-khatm",
            title: "Shab-e-Jumu'ah Awraad & Durood Gathering",
            titleUr: "شبِ جمعہ محفلِ درود و اوراد",
            isRecurringWeekly: true,
            dayOfWeek: 4,       // Every Thursday
            startHour: 21,      // 9:00 PM
            startMinute: 0,
            durationMinutes: 45,
            location: "Online / Home",
            description: "Shab-e-Jumu'ah mein Dalail-ul-Khairat aur khas Durood Shareef ka ihtimam.",
            meetUrl: ""
        },
        {
            id: "monthly-gyarhween",
            title: "Monthly Gyarhween Shareef Fatiha",
            titleUr: "ماہانہ گیارہویں شریف فاتحہ",
            // One-time / specific dated event format: "YYYY-MM-DD"
            date: "2026-12-21",
            startHour: 20,      // 8:00 PM
            startMinute: 0,
            durationMinutes: 60,
            location: "Silsila e Alaviya Nooriya",
            description: "Hazrat Ghaus-e-Azam (R.A.) ki niyaz aur Fatiha khwani.",
            meetUrl: ""
        }
    ]
};


